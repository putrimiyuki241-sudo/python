
nilai_BMI = float(input("Masukkan nilai BMI: "))
if nilai_BMI <= 18.5:
   print("kurus")
elif nilai_BMI <= 25:
   print("normal")
elif nilai_BMI <= 30:
    print("gemuk")
else:
   print("obesitas")
