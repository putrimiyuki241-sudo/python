M = input("tipe mutan: ")
jumlah_armor = int(input("masukkan jumlah bone armor: "))
senjata = input("masukkan senjata: ")
kewarasan = int(input("masukkan kewarasan: "))

if M == "armsy":
    hp_mutan = 100
    damage_mutan = 100
elif tipe_mutan == "cowman": 
    hp_mutan = 80
    damage_mutan = 80 
elif tipe_mutan = "virginia":
    hp_mutan = 60
    damage_mutan = 65
    
nyawa_ky = 100
if M == "cowman" and kewaraswan < 40:
    damage_muatan += 25

pengurangan_armor = M*5
damage_diterima = damage_muatan - pengurangan_armor
if damage_diterima < 5:
    damage_diterima = 5
    
nyawa_ky -= damage_diterima
